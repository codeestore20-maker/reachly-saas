#!/bin/bash
echo "🚀 Running updated_at migration on Railway..."
npm run migrate:updated-at
echo "✅ Migration completed!"
